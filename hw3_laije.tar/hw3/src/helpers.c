#include "helpers.h"

int my_chdir(char *args) {
    // if no arguments, use value of HOME environment
    if (strcmp(args, "cd") == 0) {
        fprintf(stdout, "%s\n", "directory == NULL");
        args = getenv("HOME");
        fprintf(stdout, "args: %s\n", args);
        return chdir(args);
    }
    else {
        char* directory = args+3;
        fprintf(stdout, "args: %s\n", directory);
        // invalid directory
        if (directory) {
            return chdir(directory);
        }
        else {
            fprintf(stderr, DIR_ERR);
            return chdir(directory);
        }
    }
    return 0;
}
