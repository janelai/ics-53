// Useage statement
#define USAGE "usage:\n53wgrep -n\n53wgrep -l WORD [-I] [-S]\n53wgrep -h WORD [-I] [-S] [-C FG BG]\n"

#include <stdio.h>
#include <stdlib.h>
#include "helpers1.h"
