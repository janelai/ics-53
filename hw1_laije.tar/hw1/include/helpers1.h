// Declare all helper functions for hw1 in this file
# ifndef HW1_HELPERS
# define HW1_HELPERS

int write_error();
int write_l(int i);
int write_ls(int occurrences, int chars, int lines);
int exit_status(int i);
int find_n();
int h_helper(char* w, int i, int s, int fg, int bg);
int l_helper(char* w, int i, int s);

# endif