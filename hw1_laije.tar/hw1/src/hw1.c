#include "hw1.h"
#include <stdio.h>
#include <string.h>
// You may define any helper functions you want. Place them in helpers.c/.h

// Main program
int main(int argc, char *argv[]) {

    // -n
    if (strcmp(argv[1], "-n") == 0)
    {
        // if it has other argument options
        if (argv[2])
        {
            write_error();
            return exit_status(-1);
        }
        return find_n();
    }

    // -h
    else if (strcmp(argv[1], "-h") == 0)
    {
        if (argv[2])  // if argv[2] exists, check for more options
        {
            char* word;
            word = argv[2];
            if (!argv[3])  // -h WORD
            {
                return h_helper(word, 1, 0, 0, 0);
            }
            else if (!argv[4])  // -h WORD [something]
            {
                if (strcmp(argv[3], "-I") == 0)  // -h WORD -I
                {
                    return h_helper(word, 2, 0, 0, 0);
                }
                else if (strcmp(argv[3], "-S") == 0)  // -h WORD -S
                {
                    return h_helper(word, 1, 1, 0, 0);
                }
            }
            else if (!argv[5])  // -h WORD [something1] [something2]
            {
                if ((strcmp(argv[3], "-I") == 0 && strcmp(argv[4], "-S") == 0) || (strcmp(argv[3], "-S") == 0 && strcmp(argv[4], "-I") == 0))  // if both [something]s are valid
                {
                    return h_helper(word, 2, 1, 0, 0);
                }
                else  // if either [something] is not valid
                {
                    write_error();
                    return exit_status(-1);
                }
            }
            else if (!argv[6])  // -h WORD C FG BG
            {
                if (strcmp(argv[3], "-C") == 0)
                {
                    int numfg = atoi(argv[4]);
                    int numbg = atoi(argv[5]);
                    if ((numfg >= 30) && (numfg <= 37) && (numbg >= 40) && (numbg <= 47))
                    {
                        h_helper(word, 1, 0, numfg, numbg);
                    }
                    else
                    {
                        write_error();
                        return exit_status(-1);
                    }
                }
                else
                {
                    write_error();
                    return exit_status(-1);
                }
            }
            else if (!argv[7])  // -I -C f b, -C f b -I, -S -C f b, -C f b -S
            {
                if (strcmp(argv[3], "-C") == 0)
                {
                    int numfg = atoi(argv[4]);
                    int numbg = atoi(argv[5]);
                    if ((numfg >= 30) && (numfg <= 37) && (numbg >= 40) && (numbg <= 47))  // valid -C
                    {
                        if (strcmp(argv[6], "-I") == 0)  // -C -I
                        {
                            return h_helper(word, 2, 0, numfg, numbg);
                        }
                        else if (strcmp(argv[6], "-S") == 0)  // -C -S
                        {
                            return h_helper(word, 1, 1, numfg, numbg);
                        }
                        else
                        {
                            write_error();
                            return exit_status(-1);
                        }
                    }
                    else
                    {
                        write_error();
                        return exit_status(-1);
                    }
                }
                else if (strcmp(argv[4], "-C") == 0)
                {
                    int numfg = atoi(argv[5]);
                    int numbg = atoi(argv[6]);
                    if ((numfg >= 30) && (numfg <= 37) && (numbg >= 40) && (numbg <= 47))  // valid -C
                    {
                        if (strcmp(argv[3], "-I") == 0)  // -I -C
                        {
                            return h_helper(word, 2, 0, numfg, numbg);
                        }
                        else if (strcmp(argv[3], "-S") == 0)  // -S -C
                        {
                            return h_helper(word, 1, 1, numfg, numbg);
                        }
                        else
                        {
                            write_error();
                            return exit_status(-1);
                        }
                    }
                    else
                    {
                        write_error();
                        return exit_status(-1);
                    }
                }
                else
                {
                    write_error();
                    return exit_status(-1);
                }
            }
            else if (!argv[8])
            {
                if (strcmp(argv[3], "-C") == 0)  // -C f b -I -S, -C f b -S -I
                {
                    int numfg = atoi(argv[4]);
                    int numbg = atoi(argv[5]);
                    if ((numfg >= 30) && (numfg <= 37) && (numbg >= 40) && (numbg <= 47))  // valid -C
                    {
                        if ((strcmp(argv[6], "-I") == 0 && strcmp(argv[7], "-S") == 0) || (strcmp(argv[6], "-S") == 0 && strcmp(argv[7], "-I") == 0))  // -I -S, -S -I
                        {
                            return h_helper(word, 2, 1, numfg, numbg);
                        }
                        else
                        {
                            write_error();
                            return exit_status(-1);
                        }
                    }
                    else
                    {
                        write_error();
                        return exit_status(-1);
                    }
                }
                else if (strcmp(argv[4], "-C") == 0)  // -I -C f b -S, -S -C f b -I
                {
                    int numfg = atoi(argv[5]);
                    int numbg = atoi(argv[6]);
                    if ((numfg >= 30) && (numfg <= 37) && (numbg >= 40) && (numbg <= 47))  // valid -C
                    {
                        if ((strcmp(argv[3], "-I") == 0 && strcmp(argv[7], "-S") == 0) || (strcmp(argv[3], "-S") == 0 && strcmp(argv[7], "-I") == 0))  // -I -S, -S -I
                        {
                            return h_helper(word, 2, 1, numfg, numbg);
                        }
                        else
                        {
                            write_error();
                            return exit_status(-1);
                        }
                    }
                    else
                    {
                        write_error();
                        return exit_status(-1);
                    }
                }
                else if (strcmp(argv[5], "-C") == 0)  // -I -S -C f b, -S -I -C f b
                {
                    int numfg = atoi(argv[6]);
                    int numbg = atoi(argv[7]);
                    if ((numfg >= 30) && (numfg <= 37) && (numbg >= 40) && (numbg <= 47))  // valid -C
                    {
                        if ((strcmp(argv[3], "-I") == 0 && strcmp(argv[4], "-S") == 0) || (strcmp(argv[3], "-S") == 0 && strcmp(argv[4], "-I") == 0))  // -I -S, -S -I
                        {
                            return h_helper(word, 2, 1, numfg, numbg);
                        }
                        else
                        {
                            write_error();
                            return exit_status(-1);
                        }
                    }
                    else
                    {
                        write_error();
                        return exit_status(-1);
                    }
                }
                else
                {
                    write_error();
                    return exit_status(-1);
                }
            }
            else
            {
                write_error();
                return exit_status(-1);
            }
        }
        else  // if no argument after -h, return error
        {
            write_error();
            return exit_status(-1);
        }
    }

    // -l
    else if (strcmp(argv[1], "-l") == 0)
    {
        if (argv[2])  // if argv[2] exists, check for more options
        {
            char* word;
            word = argv[2];
            if (!argv[3])  // -l WORD
            {
                return l_helper(word, 1, 0);
            }
            else if (!argv[4])  // -l WORD [something]
            {
                if (strcmp(argv[3], "-I") == 0)  // -l WORD -I
                {
                    return l_helper(word, 2, 0);
                }
                else if (strcmp(argv[3], "-S") == 0)  // -l WORD -S
                {
                    return l_helper(word, 1, 1);
                }
                
                else  // if [something] is not valid
                {
                    write_error();
                    return exit_status(-1);
                }
            }
            else if (!argv[5])  // -l WORD [something1] [something2]
            {
                if ((strcmp(argv[3], "-I") == 0 && strcmp(argv[4], "-S") == 0) || (strcmp(argv[3], "-S") == 0 && strcmp(argv[4], "-I") == 0))  // if both [something]s are valid
                {
                    return l_helper(word, 2, 1);
                }
                else  // if either [something] is not valid
                {
                    write_error();
                    return exit_status(-1);
                }
            }
            else
            {
                write_error();
                return exit_status(-1);
            }
        }
        else  // if no argument after -l, return error
        {
            write_error();
            return exit_status(-1);
        }
    }
    return 0;
}
