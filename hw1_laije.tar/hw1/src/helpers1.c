// Declare all helper functions for hw1 in this file
//#include "helpers1.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <hw1.h>

int write_error()
{
    FILE* filename;
    filename = fopen("student_error.txt", "w+");
    fputs(USAGE, filename);
    fclose(filename);
};

int write_l(int i)  // write match occurrences for -l
{
    // FILE* filename;
    // filename = fopen("student_error.txt", "w+");
    // fprintf(filename, "%d", i);
    // fputs("\n", filename);
    // fclose(filename);
    fprintf(stderr, "%d\n", i);
};

int write_ls(int occurrences, int chars, int lines)  // for -l -S printing
{
    // FILE* filename;
    // filename = fopen("student_error.txt", "w+");
    // fprintf(filename, "%d ", occurrences);
    // fprintf(filename, "%d ", chars);
    // fprintf(filename, "%d", lines);
    // fputs("\n", filename);
    // fclose(filename);
    fprintf(stderr, "%d %d %d\n", occurrences, chars, lines);
};

int exit_status(int i)
{
    if (i > 0)  // successful termination
    {
        return 0;
    }
    else if (i < 0)  // invalid args
    {
        return 1;
    }
    return 2;  // no occurrence found
};

int find_n()
{
    int count = 0;
    char c = getchar();
    while (c != EOF)
    {
        if (isdigit(c))  // if c is a numerical value, print it out
        {
            count++;  // at least one number exists
            char numstr[50];
            numstr[0] = '\0';
            char* pc;
            pc = &c;
            strncat(numstr, pc, 1);
            c = getchar();
            while (isdigit(c) && c != EOF)  // extend numerical value if necessary
            {
                pc = &c;
                strncat(numstr, pc, 1);
                c = getchar();
            }
            printf("%s\n", numstr);
            numstr[0] = '\0';
        }
        else
        {
            c = getchar();
        }
    }
    return exit_status(count);
};

int h_helper(char* w, int i, int s, int fg, int bg)
{
    int type = i;  // either -h (1) or -h -I (2)
    int iss = s;  // -S
    int fore = fg;  // -C
    int back = bg;
    int total_chars = 0;
    int word_count = 0;
    int line_num = 1;
    char c = getchar();
    while (c != EOF)
    {
        if (c != ' ' && c != '\n')  // start of new word
        {
            //printf("%c", c);
            total_chars++;
            char wordstr[50];
            wordstr[0] = '\0';
            char* pc;
            pc = &c;
            strncat(wordstr, pc, 1);
            c = getchar();
            while (c != ' ' && c != '\n' && c != EOF)  // if delimiter, "cut off" word
            {
                //printf("%c", c);
                total_chars++;
                pc = &c;
                strncat(wordstr, pc, 1);
                c = getchar();
            }
            // printf("Word found:%s\n", wordstr);
            if (type == 1)  // -h
            {
                if (strcmp(wordstr, w) == 0)
                {
                    word_count++;
                    if (fore > 0 && back > 0)  // -C
                    {
                        printf("\033[%d;%dm", fore, back);
                        printf("%s", wordstr);
                        printf("\x1B[39;49m");
                        // printf("\033[0m");
                    }
                    else
                    {
                        printf("\033[37;41m");
                        printf("%s", wordstr);
                        printf("\x1B[39;49m");
                        // printf("\033[0m");
                    }
                }
                else
                {
                    printf("%s", wordstr);
                }
            }
            else if (type == 2)  // -h -I
            {
                if (strcasecmp(wordstr, w) == 0)
                {
                    word_count++;
                    if (fore > 0 && back > 0)  // -C
                    {
                        printf("\033[%d;%dm", fore, back);
                        printf("%s", wordstr);
                        printf("\x1B[39;49m");
                        // printf("\033[0m");
                    }
                    else
                    {
                        printf("\033[37;41m");
                        printf("%s", wordstr);
                        printf("\x1B[39;49m");
                        // printf("\033[0m");
                    }
                }
                else
                {
                    printf("%s", wordstr);
                }
            }
            wordstr[0] = '\0';
        }
        else
        {
            if (c == '\n')  // increment line number
            {
                line_num++;
            }
            printf("%c", c);
            c = getchar();
            total_chars++;
        }
    }
    if (iss && word_count > 0)
    {
        write_ls(word_count, total_chars, line_num);
    }
    return exit_status(word_count);
};

int l_helper(char* w, int i, int s)
{
    int type = i;  // either -l or -l -I
    int iss = s;  // -S
    int total_chars = 0;
    int word_count = 0;
    int line_num = 1;
    int word_pos = 1;
    char c = getchar();
    while (c != EOF)
    {
        if (c != ' ' && c != '\n')  // start of new word
        {
            total_chars++;
            char wordstr[50];
            wordstr[0] = '\0';
            char* pc;
            pc = &c;
            strncat(wordstr, pc, 1);
            c = getchar();
            while (c != ' ' && c != '\n' && c != EOF)  // if delimiter, "cut off" word
            {
                total_chars++;
                pc = &c;
                strncat(wordstr, pc, 1);
                c = getchar();
            }
            
            // printf("%s , ln %d , word position %d\n", wordstr, line_num, word_pos);
            if (type == 1)  // -l
            {
                if (strcmp(wordstr, w) == 0)
                {
                    printf("%d:%d\n", line_num, word_pos);
                    word_count++;
                }
            }
            else if (type == 2)  // -l -I
            {
                if (strcasecmp(wordstr, w) == 0)
                {
                    printf("%d:%d\n", line_num, word_pos);
                    word_count++;
                }
            }
            word_pos++;
            wordstr[0] = '\0';
        }
        else
        {
            if (c == '\n')  // increment line number
            {
                line_num++;
                word_pos = 1;
            }
            c = getchar();
            total_chars++;
        }
    }

    // printf("total chars: %d\n", total_chars);
    // only if at least 1 occurrence of WORD is found
    if (word_count > 0)
    {
        if (iss)  // if -S
        {
            write_ls(word_count, total_chars, line_num);
        }
        else
        {
            write_l(word_count);
        }
    }
    return exit_status(word_count);
};